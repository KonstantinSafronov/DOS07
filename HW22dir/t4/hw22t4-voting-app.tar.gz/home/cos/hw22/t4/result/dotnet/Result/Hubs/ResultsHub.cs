﻿using Microsoft.AspNetCore.SignalR;

namespace Result.Hubs
{
    public class ResultsHub : Hub
    {
        //no public methods, only used for push from PublishRTesultsTimer
    }
}
